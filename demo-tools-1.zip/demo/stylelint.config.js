export default {
  extends: ["stylelint-config-standard"],
  overrides: [
    {
      files: ["**/*.html"],
      customSyntax: "postcss-html"
    }
  ],
  rules: {
    "block-no-empty": true,
    "declaration-block-no-duplicate-properties": true,
    "color-hex-length": "short"
  }
};