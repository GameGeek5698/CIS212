// eslint.config.js (ESLint v9 "flat config")
import js from '@eslint/js';
import htmlPlugin from '@html-eslint/eslint-plugin';
import htmlParser from '@html-eslint/parser';

export default [
  // Ignore build artifacts
  { ignores: ['node_modules/**', 'dist/**', 'build/**'] },

  // (Optional) JS linting using ESLint's recommended set
  {
    files: ['**/*.js'],
    ...js.configs.recommended,
    languageOptions: {
      ecmaVersion: 2021,
      sourceType: 'script'
    }
  },

  // HTML linting via @html-eslint
  {
    files: ['**/*.html'],
    languageOptions: {
      parser: htmlParser
    },
    plugins: {
      '@html-eslint': htmlPlugin
    },
    rules: {
      '@html-eslint/no-duplicate-id': 'error',
      '@html-eslint/require-doctype': 'warn',
      '@html-eslint/indent': ['warn', 2]
    }
  }
];
